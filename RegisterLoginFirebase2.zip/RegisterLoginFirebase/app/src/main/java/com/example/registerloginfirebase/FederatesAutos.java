package com.example.registerloginfirebase;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class FederatesAutos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.federates_autos);
    }
}
