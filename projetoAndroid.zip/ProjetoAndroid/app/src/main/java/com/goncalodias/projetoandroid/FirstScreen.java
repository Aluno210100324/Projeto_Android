package com.goncalodias.projetoandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.goncalodias.projetoandroid.databinding.ActivityNavBinding;
import com.google.android.material.navigation.NavigationView;

public class FirstScreen extends AppCompatActivity {

    ImageButton imgBtn;
    ImageButton imgBtn2;
    ImageButton imgBtn3;
    ImageButton imgBtn4;
    ImageButton imgBtn5;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav);

        imgBtn = (ImageButton) findViewById(R.id.imageButton);
        imgBtn2 = (ImageButton) findViewById(R.id.imgBtnMotos);
        imgBtn3 = (ImageButton) findViewById(R.id.imgBtnQuads);
        imgBtn4 = (ImageButton) findViewById(R.id.imgBtnSSV);
        imgBtn5 = (ImageButton) findViewById(R.id.imgBtnAutos);

        imgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(FirstScreen.this, News.class);
                startActivity(in);
            }
        });
        imgBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(FirstScreen.this, FederatesMotos.class);
                startActivity(in);
            }
        });
        imgBtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(FirstScreen.this, FederatesQuads.class);
                startActivity(in);
            }
        });
        imgBtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(FirstScreen.this, FederatesSSV.class);
                startActivity(in);
            }
        });
        imgBtn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(FirstScreen.this, FederatesAutos.class);
                startActivity(in);
            }
        });
    }
}
